#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "contact.h"
#include "file.h"
//#include "populate.h"
//This function is used to validate the name
int validName(char name[])
{
				int len=strlen(name);
				if(len ==0){
								return 0;
				}
				for(int i=0;i<len;i++){
								if(!isalpha(name[i]) && name[i]!=' '){
												return 0;
								}
				}
				return 1;

}
//This function is used to validate the phone
int validPhone(AddressBook *addressBook, char phone[],int index){
				int len = strlen(phone);

				if(len!=10){
								printf("Number must contain 10 digits!!\n");
								return 0;
				}
				if(phone[0]<'6' || phone[0]>'9'){
								printf("phone number must starts with 6,7,8 or 9\n");
								return 0;
				}
				for(int i=0;i<len;i++){
								if(!isdigit(phone[i])){
												printf("Error : phone number only contains digits!!!\n");
												return 0;
								}
				}

				for(int i=0;i<addressBook->contactCount;i++){
								if(i==index){
												continue;
								}
								if(strcmp(addressBook->contacts[i].phone,phone)==0){
												printf("This number already exist!!!\n");
												return 0;
								}
				}
				return 1;
}
//This function is used to validate the email
int validEmail(AddressBook *addressBook, char email[],int index){

				int count=0;
				char *atptr= strchr(email, '@');
				char *tempat=atptr;
				char *dptr = strstr(email, ".com");
				char *tempDot=dptr;

				while(tempat!=NULL){
								count++;
								tempat=strchr(tempat + 1,'@');
				}
				if(count != 1){
								printf("Email must contain exactly one @ symbol\n");
								return 0;
				}

				int comcount=0;
				while(tempDot!=NULL){
								comcount++;
								tempDot=strstr(tempDot + 4,".com");
				}
				if(comcount != 1){
								printf("Email must contain exactly one '.com'\n");
								return 0;
				}
				if(atptr > dptr){
								printf("Invalid : @ must appear before .com\n");
								return 0;
				}

				if(atptr +1 == dptr){
								printf("Email must have a domain (e.g., user@domain.com\n");
								return 0;
				}
				if(strcmp(dptr, ".com")!=0){
								printf("Email must end with '.com'\n");
								return 0;
				}
				if(isdigit(email[0])){
								printf("Email must start with alphabet\n");
								return 0;
				}



				for(int i=0;email[i]!='\0';i++){
								if(isalpha(email[i]) && !islower(email[i])){
												printf("Email must be lowercase\n");
												return 0;
								}
				}
				for(int i=0;i<addressBook->contactCount;i++){
								if(i==index){
												continue;
								}
								if(strcmp(addressBook->contacts[i].email,email)==0){
												printf("This Email already exist!!!\n");
												return 0;
								}
				}
				char *domain = atptr + 1;   // start after '@'

                while(domain < dptr) {
                if(!isalpha(*domain)) {
                printf("Invalid: Domain must contain only alphabets\n");
                return 0;
                }
                domain++;
                }
				return 1;

}
//This function is used to search the name
int nameSearch(AddressBook *addressBook, char name[]){
				int found=0;
				for(int i=0;i<addressBook->contactCount;i++){
								if(strcmp(addressBook->contacts[i].name,name)==0){
												if(found==0){
																printf("\nContact Found!\n");
																printf("\n%-5s | %-20s | %-15s | %-25s\n", "S.No", "Name", "Phone", "Email");
																printf("--------------------------------------------------------------------\n");
												}
												printf("%-5d | %-20s | %-15s | %-25s\n",i+1,
																				addressBook->contacts[i].name,
																				addressBook->contacts[i].phone,
																				addressBook->contacts[i].email);
												found++;

								}
				}
				if(found > 0){
								printf("---------------------------------------------------------------------\n");
								return 1;
				}else{

								printf("The contact %s is not found!!",name);
				}

}
//This function is used to search the phone
int phoneSearch(AddressBook *addressBook, char phone[]){
				int found=0;
				for(int i=0;i<addressBook->contactCount;i++){
								if(strcmp(addressBook->contacts[i].phone,phone)==0){
												if(found==0){
																printf("\nContact Found!\n");
																printf("\n%-5s | %-20s | %-15s | %-25s\n", "S.No", "Name", "Phone", "Email");
																printf("--------------------------------------------------------------------\n");
												}
												printf("%-5d | %-20s | %-15s | %-25s\n", i+1,
																				addressBook->contacts[i].name,
																				addressBook->contacts[i].phone,
																				addressBook->contacts[i].email);
												found=1;

								}
				}
				if(found==0)
				{				printf("The %s is not found!!",phone);
								return 0;
				}
				printf("--------------------------------------------------------------------\n");
				return 1;
}
//This function is used to search the email
int emailSearch(AddressBook *addressBook, char email[]){
				int found=0;
				for(int i=0;i<addressBook->contactCount;i++){
								if(strcmp(addressBook->contacts[i].email,email)==0){
												if(found == 0){
																printf("\nContact Found!\n");
																printf("\n%-5s | %-20s | %-15s | %-25s\n", "S.No", "Name", "Phone", "Email");
																printf("--------------------------------------------------------------------\n");
												}
												printf("%-5d | %-20s | %-15s | %-25s\n", i+1,
																				addressBook->contacts[i].name,
																				addressBook->contacts[i].phone,
																				addressBook->contacts[i].email);
												found=1;

								}
				}
				if(found==0)
				{				printf("The %s is not found!!",email);
								return 0;
				}
				printf("--------------------------------------------------------------------\n");
				return 1;
}





void listContacts(AddressBook *addressBook) 
{
				// Sort contacts based on the chosen criteria

				if(addressBook->contactCount == 0){
								printf("Contact is Empty!!");
								return;

				}
				printf("\n%-5s | %-20s |%-15s | %-25s\n", "S.No", "Name", "Phone", "Email");
				printf("--------------------------------------------------------------------\n");
				for(int i=0; i<addressBook->contactCount;i++){
								printf("%-5d | %-20s | %-15s | %-25s\n",i+1,
																addressBook->contacts[i].name,
																addressBook->contacts[i].phone,
																addressBook->contacts[i].email);
				}
				printf("---------------------------------------------------------------------\n");

}
				
void initialize(AddressBook *addressBook) {
				addressBook->contactCount = 0;


				loadContactsFromFile(addressBook);
}

void saveAndExit(AddressBook *addressBook) {
				saveContactsToFile(addressBook); // Save contacts to file
				exit(EXIT_SUCCESS); // Exit the program
}


void createContact(AddressBook *addressBook)
{
				/* Define the logic to create a Contacts */
				char tempName[50];
				char tempPhone[20];
				char tempEmail[50];

				if(addressBook->contactCount >= MAX_CONTACTS){
								printf("Error : Address book is full!!");
								return;
				}

				printf("\n-------Creating New Contact--------\n");
				int nameflag=0;
				for(int i=1;i<=3;i++){

								printf("Enter the name you have %d/3 attempts : ",i);
								scanf(" %[^\n]",tempName);
								if(strlen(tempName)==0){
												printf("Name can't be Empty!!");
								}


								if(validName(tempName)){
												nameflag=1;
												break;
								}else{
												printf("!!!Invalid : Only alphabet characters are allowed!!!\n");
								}
				}
				if(!nameflag){
								printf("!!Too many attempts, Try later!!\n");
								return;
				}

				int phoneflag=0;
				for(int i=1;i<=3;i++){
								printf("Enter the phone number You have %d/3 attempts : ",i);
								scanf(" %s",tempPhone);
								if(validPhone(addressBook, tempPhone,-1)){
												phoneflag=1;
												break;
								}
				}
				if(!phoneflag){
								printf("\n!!Too many attempts, Try later!!\n");
								return;
				}
				int emailflag=0;
				for(int i=1;i<=3;i++){
								printf("Enter the email You have %d/3 attempts : ",i);
								scanf(" %s",tempEmail);
								if(validEmail(addressBook, tempEmail,-1)){
												emailflag=1;
												break;
								}
				}
				if(!emailflag){
								printf("Too many attempts, Try later\n");
								return;
				}


				int i = addressBook->contactCount;
				strcpy(addressBook->contacts[i].name,tempName);
				strcpy(addressBook->contacts[i].phone,tempPhone);
				strcpy(addressBook->contacts[i].email,tempEmail);

				addressBook->contactCount++;

				printf("Contact created Sucessfully!!\n");


}





void searchContact(AddressBook *addressBook) 
{
				/* Define the logic for search */
				if(addressBook->contactCount==0){
								printf("AddressBook is Empty!! Nothing to search!!");
								return;
				}
				char name[50];
				char phone[20];
				char email[50]; 
				int choice;
				printf("Choose what you want to search\n");
				printf("1.Name\n2.Phone\n3.Email\n");
				printf("Enter the choice : ");
				scanf("%d",&choice);

				switch (choice){
								case 1 :

												printf("Enter the name to search : ");
												scanf(" %[^\n]",name);
												nameSearch(addressBook, name);
												break;
								case 2 :

												printf("Enter the phone number to search : ");
												scanf(" %[^\n]",phone);
												phoneSearch(addressBook, phone);
												break;
								case 3 :

												printf("Enter the email id to search : ");
												scanf(" %[^\n]",email);
												emailSearch(addressBook, email);
												break;
								default :

												printf("Invalid choice!!");
				}


}

void editContact(AddressBook *addressBook)
{
				/* Define the logic for Editcontact */
				char edit[50];
				int index[50];
				int count=0;
				int choice;


				if(addressBook->contactCount==0){
								printf("Addressbook is empty\n");
								return;
				}
				printf("Enter the name of the contact to edit : ");
				scanf(" %[^\n]",edit);

				printf("\n%-5s | %-20s |%-15s | %-25s\n", "S.No", "Name", "Phone", "Email");
				printf("--------------------------------------------------------------------\n");

				for(int i=0;i<addressBook->contactCount;i++){
								if(strcmp(addressBook->contacts[i].name,edit)==0){
												index[count]=i;
												printf("%-5d | %-20s | %-15s | %-25s\n",count+1,
																				addressBook->contacts[i].name,
																				addressBook->contacts[i].phone,
																				addressBook->contacts[i].email);

												count++;

								}

				}
				if(count ==0){
								printf("Contact not found!!");
								return;
				}
				int choose=1;
				if(count>1){
								printf("Multiply contacts found select from 1 to %d to edit : ",count);
								scanf("%d",&choose);
								if(choose < 1 || choose > count){
												printf("Invalid choice\n");
												return;
								}
				}

				int indexFound=index[choose -1];



				printf("Contact Found! Editing.. %s\n",addressBook->contacts[indexFound].name);
				printf("1. Name\n2. phone\n3. Email\n4. Exit\n");
				printf("Enter the choice : ");
				scanf("%d",&choice);

				switch(choice){
								case 1:{	
															 char tempname[50];
															 int nameflag=0;
															 for(int i=1;i<=3;i++){
																			 printf("Enter the name, You have %d/3 attempts : ",i);
																			 scanf(" %[^\n]",tempname);
																			 if(validName(tempname)){
																							 strcpy(addressBook->contacts[indexFound].name,tempname);
																							 nameflag=1;
																							 break;
																			 }else{
																							 printf("Error : Enter only alphabets!!\n");
																			 }
															 }
															 printf(nameflag ? "Contact updated sucessfully!\n" : "Too many attempts.\n");
															 break;
											 }


								case 2:{
															 char tempphone[20];
															 int phoneflag=0;
															 for(int i=1;i<=3;i++){

																			 printf("Enter the phone number, You have %d/3 attempts : \n",i);
																			 scanf(" %[^\n]",tempphone);
																			 if(validPhone(addressBook,tempphone,indexFound)){
																							 strcpy(addressBook->contacts[indexFound].phone,tempphone);
																							 phoneflag=1;
																							 break;
																			 }
															 }
															 printf(phoneflag ? "Contact updated sucessfully!\n" : "Too many attempts.\n");
															 break;
											 }

								case 3: {
																char tempemail[50];
																int emailflag=0;
																for(int i=1;i<=3;i++){
																				printf("Enter the Email, You have %d/3 attempts : \n",i);
																				scanf(" %[^\n]",tempemail);
																				if(validEmail(addressBook,tempemail,indexFound)){
																								strcpy(addressBook->contacts[indexFound].email,tempemail);
																								emailflag=1;
																								break;
																				}
																}
																printf(emailflag ? "Contact updated sucessfully!\n" : "Too many attempts.\n");
																break;
												}


								case 4:
												return;
								default :
												printf("Invalid Choice!!!");
												return;
				}






}

void deleteContact(AddressBook *addressBook)
{
				/* Define the logic for deletecontact */
				printf("Current contact count is %d\n",addressBook->contactCount);
				char name[50];
				int index[50];
				int count=0;
				if(addressBook->contactCount==0){
								printf("AddressBook is Empty!!\n");
								return;
				}
				printf("Enter the name to delete : ");
				scanf(" %[^\n]",name);

				for(int i=0;i<addressBook->contactCount;i++){
								if(strcmp(addressBook->contacts[i].name,name)==0){
												index[count]=i;
												printf("%d.Name : %s | Phone : %s | Email %s\n",count+1,
																				addressBook->contacts[i].name,
																				addressBook->contacts[i].phone,
																				addressBook->contacts[i].email);
												count++;

								}
				}
				if(count == 0){
								printf("Contact Not Found");
								return;
				}
				int choose=1;
				if(count > 1){
								printf("Multiple contacts are found select 1-%d to delete : ",count);
								scanf("%d",&choose);
								if(choose < 1 || choose > count){
												printf("Invalid choise");
												return;
								}
				}
				int found=index[choose -1];

				for(int i=found;i<addressBook->contactCount-1;i++){
								addressBook->contacts[i]=addressBook->contacts[i+1];
				}
				addressBook->contactCount--;
				printf("Contact Deleted Sucessfully!!");
}
