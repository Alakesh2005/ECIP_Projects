#include <stdio.h>
#include<string.h>
#include "encode.h"
#include "decode.h"
#include "types.h"
/* Name       : Alakesh Ghorui
 * Batch id   : 26001B
 * Title      : LSB Image Stegnography
 * Overview   : This project implements a LSB (Least Significant Bit) Image Steganography written in C. 
 *              The application serves as a secure, data-hiding utility capable of embedding private payloads 
 *              (files of any extension format, such as .txt, .pdf, or .png) inside an uncompressed 24-bit BMP (Bitmap) image carrier file.
 * Date of 
 * submission : 26-05-2026
 */             
OperationType check_operation_type(char *);

int main(int argc, char *argv[])
{
	if(argc<2){
		printf("ERROR Missing Arguments");
		return 0;
	}
	int op_type=check_operation_type(argv[1]);
	if(op_type==e_unsupported){
		printf("ERROR: unsupported argument passed \n");
		return e_failure;
	}
	if(op_type==e_encode){
		printf("Encoding starting");

		EncodeInfo encInfo;
		if(read_and_validate_encode_args(argv,&encInfo)==e_success)
		{
			if(do_encoding(&encInfo)==e_success)
			{
				printf("Encoding completed successfully");
			}
			else{
				printf("Encoding failed");
				return 0;
			}
		}
		else{
			printf("Error : Read and Validate arguments failed\n");
			return e_failure;
		}
	}
	if(op_type==e_decode){
	printf("Decoding starting");
	DecodeInfo decInfo;
	if(read_and_validate_decode_args(argv,&decInfo)==e_success){
	if(do_decoding(&decInfo)==e_success){
	printf("Decoding compled successfully");
	}else{
	printf("Decoding failed");
}}else{
printf("ERROR: read and validata argument failed\n");
return e_failure;

}
}
return e_success;
}


OperationType check_operation_type(char *symbol)
{
	if(symbol==NULL)
	{
		return e_unsupported;
	}
	if(strcmp(symbol,"-e")==0){
		return e_encode;
	}
	else if(strcmp(symbol,"-d")==0){
		return e_decode;
	}
	else{
		return e_unsupported;
	}
}
