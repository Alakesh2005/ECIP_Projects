import time
from sensor import SensorSimulation
from decision_engine import DecisionEngine
from calculation import EngineCalculator
from logger import DataLogger

#allocatiing the memory for the class
sensor = SensorSimulation()
engine =DecisionEngine()
calc = EngineCalculator()
logger = DataLogger()

print("sensor simulation started...\n")
try:
    while True :
        data = sensor.get_data(True)
        ac_state,reason = engine.decide(data)
        cycle_energy, cummulative_energy = calc.compute(ac_state)
        record = {
        "temperature" : data["temperature"],
        "humidity" : data["humidity"],
        "occupancy" : data["occupancy"],
        "hour" : data["hour"],
        "ac_state" : ac_state,
        "reason" : reason,
        "cycle_energy" : cycle_energy,
        "cummulative_energy" : cummulative_energy
        }
        logger.store(record)

        print(f"temperature : {data}")
        print(f"humidity:{data['humidity']}")
        print(f"occupancy:{data['occupancy']}")
        print(f"hour:{data['hour']}")
        print(f"AC state is :{ac_state}")
        print(f"Reason : {reason}") 
        print(f"cycle energy: {cycle_energy}")
        print(f"cummulative_energy : {cummulative_energy}")
        time.sleep(2)
except KeyboardInterrupt:
    print("\n"  + "-"*70)
    print("simulation stopped by user!!!")
    print(f"Total energy  consumed : {cummulative_energy} units")
    print(f"simulation is stopping after : {logger.count()} cycles")