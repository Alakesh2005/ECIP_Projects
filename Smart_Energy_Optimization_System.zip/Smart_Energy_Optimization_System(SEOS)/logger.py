class DataLogger:
    def __init__(self):
        self.records = []

    def store(self, record):
        self.records.append(record)

    def count(self):
        return len(self.records)