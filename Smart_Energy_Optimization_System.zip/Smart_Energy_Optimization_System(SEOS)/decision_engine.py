from config import *

class DecisionEngine:

    def __init__(self):
        self.ac_state = False  #assuming ac is in off state
        self.reason = ""

    def decide(self, data):
        temp = data["temperature"]
        humi = data["humidity"]
        occ = data["occupancy"]
        hour = data["hour"]
        
        #calculate the upper and lower threshold value temp
        upper = DEFAULT_THRESHOLD + DEFAULT_BUFFER
        lower = DEFAULT_THRESHOLD - DEFAULT_BUFFER

        #rule1: Room Empty check
        if occ == 0:
            self.ac_state = False
            self.reason = "Room Empty -> AC OFF"

        #rule: Outside operational hour
        elif hour < DEFAULT_OP_START or hour > DEFAULT_OP_END:
            self.ac_state = False
            self.reason = "Outside working hour -> AC OFF"

        #rule 3: High Temperature
        elif temp > upper:
            self.ac_state = True
            self.reason = "Temp High -> AC ON"

        #rule 4: Low Temperature
        elif temp < lower:
            self.ac_state = False
            self.reason = "Temp Low -> AC OFF"

        #rule 5: Hysteresis
        else: 
            self.reason = "Within band -> HOLD"

        return self.ac_state, self.reason