from config import *

class EngineCalculator: 
    def __init__(self):
        self.cummulative_energy = 0.0

    def compute(self, ac_state):

        if ac_state:
            cycle_energy = RATE_ON
        else:
            cycle_energy = RATE_OFF

        self.cummulative_energy = self.cummulative_energy + cycle_energy

        return cycle_energy, round(self.cummulative_energy,1)